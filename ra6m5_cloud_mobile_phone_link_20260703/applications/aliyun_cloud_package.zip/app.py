from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from flask import Flask, abort, jsonify, request


APP_ROOT = Path(__file__).resolve().parent
DATA_DIR = APP_ROOT / "data"
REPORTS_FILE = DATA_DIR / "reports.json"

HOST = os.getenv("APP_HOST", "0.0.0.0")
PORT = int(os.getenv("APP_PORT", "5000"))
BASE_URL = os.getenv("BASE_URL", f"http://127.0.0.1:{PORT}")

app = Flask(__name__)


QUESTIONS: list[dict[str, Any]] = [
    {
        "id": 1,
        "category": "\u671b\u8bca",
        "question": "\u8bf7\u89c2\u5bdf\u820c\u82d4\u989c\u8272",
        "options": ["\u6de1\u767d", "\u7ea2", "\u7d2b\u6697", "\u9ec4"],
    },
    {
        "id": 2,
        "category": "\u95ee\u8bca",
        "question": "\u6700\u8fd1\u7761\u7720\u8d28\u91cf\u5982\u4f55",
        "options": ["\u597d", "\u4e00\u822c", "\u8f83\u5dee"],
    },
    {
        "id": 3,
        "category": "\u95ee\u8bca",
        "question": "\u662f\u5426\u5bb9\u6613\u75b2\u52b3",
        "options": ["\u5426", "\u5076\u5c14", "\u7ecf\u5e38"],
    },
]


def ensure_storage() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not REPORTS_FILE.exists():
        REPORTS_FILE.write_text("{}", encoding="utf-8")


def load_reports() -> dict[str, Any]:
    ensure_storage()
    try:
        return json.loads(REPORTS_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def save_reports(reports: dict[str, Any]) -> None:
    ensure_storage()
    REPORTS_FILE.write_text(
        json.dumps(reports, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def build_report_url(report_id: str) -> str:
    return f"{BASE_URL}/report/{report_id}"


def create_report(payload: dict[str, Any]) -> dict[str, Any]:
    patient_name = str(payload.get("patient_name", "")).strip() or "\u672a\u547d\u540d\u60a3\u8005"
    patient_phone = str(payload.get("patient_phone", "")).strip()
    answers = payload.get("answers", [])

    report_id = f"R{int(time.time())}"
    return {
        "report_id": report_id,
        "patient_name": patient_name,
        "patient_phone": patient_phone,
        "answers": answers,
        "diagnosis": "\u6c14\u8840\u504f\u865a\uff0c\u5efa\u8bae\u7ed3\u5408\u820c\u8c61\u4e0e\u7761\u7720\u60c5\u51b5\u8fdb\u4e00\u6b65\u8fa8\u8bc1\u3002",
        "recommendations": [
            "\u4fdd\u6301\u89c4\u5f8b\u4f5c\u606f",
            "\u996e\u98df\u6e05\u6de1\uff0c\u907f\u514d\u8fc7\u5ea6\u52b3\u7d2f",
            "\u5efa\u8bae\u7ebf\u4e0b\u7ed3\u5408\u4e2d\u533b\u5e08\u9762\u8bca\u590d\u6838",
        ],
        "created_at": int(time.time()),
        "report_url": build_report_url(report_id),
    }


def send_sms_stub(phone: str, report_url: str) -> dict[str, Any]:
    return {
        "status": "stub",
        "phone": phone,
        "message": f"\u77ed\u4fe1\u529f\u80fd\u5f85\u63a5\u5165\u963f\u91cc\u4e91 SMS\uff0c\u62a5\u544a\u94fe\u63a5\uff1a{report_url}",
    }


@app.get("/health")
def health() -> Any:
    return jsonify({"status": "ok", "service": "aliyun_cloud"})


@app.get("/api/questions")
def api_questions() -> Any:
    return jsonify(QUESTIONS)


@app.post("/api/diagnosis")
def api_diagnosis() -> Any:
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400, description="JSON body required")

    report = create_report(data)
    reports = load_reports()
    reports[report["report_id"]] = report
    save_reports(reports)
    return jsonify(report)


@app.post("/api/send-sms")
def api_send_sms() -> Any:
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400, description="JSON body required")

    phone = str(data.get("phone", "")).strip()
    report_id = str(data.get("report_id", "")).strip()
    if not phone or not report_id:
        abort(400, description="phone and report_id are required")

    reports = load_reports()
    report = reports.get(report_id)
    if not report:
        abort(404, description="report not found")

    sms_result = send_sms_stub(phone, report["report_url"])
    report["sms_last_result"] = sms_result
    reports[report_id] = report
    save_reports(reports)

    return jsonify(
        {
            "status": "ok",
            "report_id": report_id,
            "report_url": report["report_url"],
            "sms": sms_result,
        }
    )


@app.get("/report/<report_id>")
def api_report(report_id: str) -> Any:
    reports = load_reports()
    report = reports.get(report_id)
    if not report:
        abort(404, description="report not found")
    return jsonify(report)


if __name__ == "__main__":
    ensure_storage()
    app.run(host=HOST, port=PORT)
